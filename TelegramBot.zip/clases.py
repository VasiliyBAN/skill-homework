import requests
from config import currency


class ConvException(Exception):
    pass


class CurrConverter:
    @staticmethod
    def convert(quote, base, value):

        if quote == base:
            raise ConvException(f'Не удалось конвертировать одинаковые валюты "{base}"')

        try:
            value == float(value) or int(value)
        except ValueError:
            raise ConvException(f'Недопустимый параметр "{value}"')

        try:
            quote_ticker = currency[quote]
        except KeyError:
            raise ConvException(f'Неизвестная валюта "{quote}"')
        try:
            base_ticker = currency[base]
        except KeyError:
            raise ConvException(f'Неизвестная валюта "{base}"')

        r = requests.get(
            f'https://v6.exchangerate-api.com/v6/0dd5ef33d8841058544ab992/pair/{base_ticker}/{quote_ticker}').json()
        return r
