TOKEN = "6647623360:AAE3ZxGuYPlBFDYnNXNNbf6W1ir66hRUrhc"

currency = {
    'доллар': 'USD',
    'евро': 'EUR',
    'рубль': 'RUB',
}
