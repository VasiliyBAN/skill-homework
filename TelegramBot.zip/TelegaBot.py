import telebot
from config import TOKEN, currency
from clases import CurrConverter, ConvException

bot = telebot.TeleBot(TOKEN)


@bot.message_handler(commands=['start', 'help'])
def send_welcome(message: telebot.types.Message):
    text = 'Введите команду в следующем формате:\n<эту валюту> перевести \
<в эту валюту>\n<количество конвертируемой валюты>\nПример: рубль доллар 200\nЧтобы узнать список \
доступных валют, введите "/values"'
    bot.reply_to(message, text)


@bot.message_handler(commands=['values'])
def values(message: telebot.types.Message):
    text = 'Вот какими валютами я оперирую на данный момент:'
    for key in currency.keys():
        text = "\n".join((text, key,))
    bot.reply_to(message, text)


@bot.message_handler(content_types=['text', ])
def convert(message: telebot.types.Message):
    try:
        values = message.text.split(' ')

        if len(values) != 3:
            raise ConvException('Неверные параметры ввода.')

        base, quote, value = values

        r = CurrConverter.convert(quote, base, value)
    except ConvException as e:
        bot.reply_to(message, f'Ошибка пользователя\n {e}')
    except Exception as e:
        bot.reply_to(message, f'Не удалось обработать команду\n {e}')
    else:
        text = f"За {value} {base} придется отдать {float(r['conversion_rate']) * float(value)} {quote}"
        bot.send_message(message.chat.id, text)


bot.polling(none_stop=True)

# import requests
#
# r = requests.get(
#     f'https://v6.exchangerate-api.com/v6/0dd5ef33d8841058544ab992/pair/USD/RUB').json()
# print(r['conversion_rate'])
